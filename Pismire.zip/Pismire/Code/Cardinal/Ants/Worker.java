package Cardinal.Ants;

import Cardinal.Settings.Affinity;
import Cardinal.Settings.Context;
import Cardinal.World.Map;
import Elementals.Camera;
import Elementals.Sprite;
import Elementals.Task;
import Elementals.Timer;

public class Worker {
	private float X, Y, VelocityX, VelocityY, PointX, PointY, Speed;
	private boolean IsMoving, IsUnderground;
	private int Frame;

	private Timer Switcher;
	private Sprite Model;

	public Worker (float X, float Y) {
		this.Model = Affinity.t128e128 ().GetSprite (Affinity.WORKER_TEXTURE);
		this.Model.SetWidth ((short) 48);
		this.Model.SetHeight ((short) 48);
		this.Model.SetLayer ((byte) 5);
		this.Frame = Affinity.WORKER_TEXTURE;
		this.IsMoving = false;
		this.Speed = 0.5f;
		this.Switcher = new Timer (30000000, 0);
		this.Switcher.Design ();

		this.Switcher.SetOnLooped (new Task () {

			@Override
			public void Run () {
				SetFrame ();

			}

		});

		this.SetPosition (X, Y);

	}

	public void Update (long Elapsed) {
		if (IsUnderground) {
			if (X > 0.0f) {
				X *= -1;

			}

		} else {
			if (X < 0.0f) {
				X *= -1;

			}

		}

		if (IsMoving) {
			SetPosition (VelocityX * Context.ELAPSED_CONSTANT * Elapsed * Speed,
					VelocityY * Context.ELAPSED_CONSTANT * Elapsed * Speed);

			if (this.X > PointX - Context.ELAPSED_CONSTANT * Elapsed * 1.0f
					&& this.X < PointX + Context.ELAPSED_CONSTANT * Elapsed * 1.0f
					&& this.Y > PointY - Context.ELAPSED_CONSTANT * Elapsed * 1.0f
					&& this.Y < PointY + Context.ELAPSED_CONSTANT * Elapsed * 1.0f) {
				VelocityX = 0;
				VelocityY = 0;
				IsMoving = false;

			}

		}

	}

	private void PathToPoint () {
		if (IsMoving) {
			float DistanceX = PointX - this.X, DistanceY = PointY - this.Y;
			float Angle = (float) Math.atan2 (DistanceY, DistanceX);

			VelocityX = (float) Math.cos (Angle);
			VelocityY = (float) Math.sin (Angle);

			Model.SetAngle ((float) Math.toDegrees (-Angle) + 90.0f);

		}

	}

	private void SetPosition (float X, float Y) {
		this.X = X + this.X;
		this.Y = Y + this.Y;

		if (IsUnderground) {
			if (this.X < -Map.GetBoundaryX () || this.X > -512.0f) {
				this.X -= X;

			} else {
				Model.SetX (this.X);

				if (this.X < -1472 && this.X > -Map.GetBoundaryX () + 960.0f) {
					Camera.SetX (this.X - 960.0f);

				}

			}

		} else {
			if (this.X > Map.GetBoundaryX () || this.X < 512.0f) {
				this.X -= X;
				IsMoving = false;

			} else {
				Model.SetX (this.X);

				if (this.X > 1472 && this.X < Map.GetBoundaryX () - 960.0f) {
					Camera.SetX (this.X - 960.0f);

				}

			}

		}

		if (this.Y > Map.GetBoundaryY () || this.Y < 512.0f) {
			this.Y -= Y;

		} else {
			Model.SetY (this.Y);

			if (this.Y > 1052.0f && this.Y < Map.GetBoundaryY () - 540.0f) {
				Camera.SetY (this.Y - 540.0f);

			}

		}

	}

	private void SetFrame () {
		if (IsMoving) {
			Frame++;

			if (Frame >= 8) {
				Frame = 0;

			}

			this.Model = Affinity.t128e128 ().GetSprite ((short) Frame, Model);

		}

	}

	public void MoveTowards (float X, float Y) {
		this.PointX = X;
		this.PointY = Y;

		if (Math.abs (this.X - PointX) > 8.0f || Math.abs (this.Y - PointY) > 8.0f) {
			IsMoving = true;

		}

		PathToPoint ();

	}

	public void SetIsUnderground (boolean IsUnderground) {
		this.IsUnderground = IsUnderground;

		if (IsUnderground) {
			if (this.X > -1472) {
				Camera.SetX (-2432.0f);

			}

		} else {
			if (this.X < 1472) {
				Camera.SetX (512.0f);

			}

		}

		if (this.Y < 1052) {
			Camera.SetY (512.0f);

		}

	}

	public float GetX () {
		return this.X;

	}

	public float GetY () {
		return this.Y;

	}

}