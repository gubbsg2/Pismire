package Cardinal.World;

import Cardinal.Settings.Affinity;
import Elementals.Random;
import Elementals.Sprite;

public class Anthill {
	private int Stage;

	private Sprite Model;

	public Anthill (float X, float Y) {
		Model = Affinity.t256256 ().GetSprite (Affinity.ANTHILL_STAGES);
		Model.SetX (X);
		Model.SetY (Y);
		Model.SetAngle (Random.Float (0.0f, 360.0f));
		Model.SetLayer ((byte) 3);

	}

	public void Upgrade () {
		Stage++;

		if (Stage > 135) {
			Model.SetWidth ((short) (Stage * 2.0f));
			Model.SetHeight ((short) (Stage * 2.0f));

		} else {
			if (Stage % 15 == 0) {
				Model = Affinity.t256256 ().GetSprite ((short) (Stage * 0.06666666f), Model);

			}

		}

	}

}