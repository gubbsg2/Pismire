package Cardinal.World;

import Cardinal.Bugs.Beetle;
import Cardinal.Settings.Affinity;
import Cardinal.Settings.Context;
import Elementals.List;
import Elementals.Random;
import Elementals.Sprite;

public class Map {
	private static float BoundaryX, BoundaryY;
	private static List<Beetle> BeetleList;

	public static void Design () {
		Map.BoundaryX = Context.BOUNDARY_X;
		Map.BoundaryY = Context.BOUNDARY_Y;

		for (int Index = 768; Index < BoundaryY + 256; Index += 512) {
			for (int IndexTwo = 756; IndexTwo < BoundaryX + 256; IndexTwo += 512) {
				Sprite Item = Affinity.t512e512 ().GetSprite (Affinity.GROUND_TEXTURE);
				Item.SetX (IndexTwo);
				Item.SetY (Index);
				Item.SetLayer ((byte) 1);

			}

		}

		for (int Index = 768; Index < BoundaryY + 256; Index += 512) {
			for (int IndexTwo = -768; IndexTwo > -BoundaryX - 256; IndexTwo -= 512) {
				Sprite Item = Affinity.t512e512 ().GetSprite (Affinity.CAVE_TEXTURE);
				Item.SetX (IndexTwo);
				Item.SetY (Index);
				Item.SetLayer ((byte) 1);

			}

		}

		BeetleList = new List<Beetle> (Beetle.class);

		for (byte Index = 0; Index < Context.BUG_NUMBER; Index++) {
			BeetleList.Push (new Beetle (Random.Float (512.0f, BoundaryX),
					Random.Float (512.0f, BoundaryY)));

		}

		for (short Index = 0; Index < Context.GADGET_NUMBER; Index++) {
			Gadget Item = new Gadget (Affinity.t64e64 (),
					(short) Random.Integer (Affinity.LEAF_TEXTURE, Affinity.TWIG_TEXTURE),
					Random.Float (512.0f, BoundaryX), Random.Float (512.0f, BoundaryY),
					(byte) Random.Integer (32, 64), (byte) Random.Integer (32, 64),
					(short) Random.Integer (0, 359));
			Item.hashCode ();

		}

		for (short Index = 0; Index < Context.GADGET_NUMBER; Index++) {
			Gadget Item = new Gadget (Affinity.t64e64 (),
					(short) Random.Integer (Affinity.ROCK_TEXTURE, Affinity.PUDDLE_TEXTURE),
					Random.Float (-512.0f, -BoundaryX), Random.Float (512.0f, BoundaryY),
					(byte) Random.Integer (32, 64), (byte) Random.Integer (32, 64),
					(short) Random.Integer (0, 359));
			Item.hashCode ();

		}

	}

	public static void Update (long Elapsed) {
		for (short Index = 0; Index < BeetleList.Size (); Index++) {
			BeetleList.ItemAt (Index).Update (Elapsed);

		}

	}

	public static float GetBoundaryX () {
		return Map.BoundaryX;

	}

	public static float GetBoundaryY () {
		return Map.BoundaryY;

	}

}
