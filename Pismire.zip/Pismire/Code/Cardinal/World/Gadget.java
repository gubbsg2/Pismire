package Cardinal.World;

import Elementals.Atlas;
import Elementals.Sprite;

public class Gadget {
	private Sprite Model;

	public Gadget (Atlas Source, short Slot, float X, float Y, byte Width, byte Height, short Angle) {
		Model = Source.GetSprite (Slot);
		Model.SetX (X);
		Model.SetY (Y);
		Model.SetWidth (Width);
		Model.SetHeight (Height);
		Model.SetAngle (Angle);
		Model.SetLayer ((byte) 2);

	}

}