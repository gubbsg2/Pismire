package Cardinal;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_TAB;
import static org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT;

import Cardinal.Ants.Worker;
import Cardinal.Settings.Affinity;
import Cardinal.World.Anthill;
import Cardinal.World.Map;
import Elementals.Actionable;
import Elementals.Application;
import Elementals.KeyTracker;
import Elementals.MouseTracker;
import Elementals.Sprite;
import Elementals.Threader;

public class Structure extends Actionable {
	private Sprite Cursor;
	private Worker Player;
	private Anthill Hill;

	@Override
	public void Design () {
		Affinity.Design ();
		Map.Design ();

		Cursor = Affinity.t64e64 ().GetSprite ((short) Affinity.CURSOR_TEXTURE);
		Cursor.SetIsStatic (true);
		Cursor.SetIsFollowing (true);
		Cursor.SetWidth ((short) 32);
		Cursor.SetHeight ((short) 32);
		Cursor.SetLayer ((byte) 8);

		Player = new Worker (512.0f, 512.0f);
		Player.SetIsUnderground (false);

		Hill = new Anthill (999.0f, 999.0f);

	}

	@Override
	public void UpdateOne (long Elapsed) {
		Player.Update (Elapsed);
		Map.Update (Elapsed);

		if (MouseTracker.ButtonPressed ((short) GLFW_MOUSE_BUTTON_LEFT, true)) {
			Player.MoveTowards (MouseTracker.GetX (false), MouseTracker.GetY (false));

		}

		float SuggestedX = 0.0f, SuggestedY = 0.0f;
		boolean IsMoving = false;
		byte Count = 0;

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_W, true)) {
			SuggestedY += 10.0f;
			IsMoving = true;
			Count++;

		}

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_A, true)) {
			SuggestedX -= 10.0f;
			IsMoving = true;
			Count++;

		}

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_S, true)) {
			SuggestedY -= 10.0f;
			IsMoving = true;
			Count++;

		}

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_D, true)) {
			SuggestedX += 10.0f;
			IsMoving = true;
			Count++;

		}

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_E, true)) {
			Hill.Upgrade ();

		}

		if (IsMoving) {
			if (Count > 1) {
				SuggestedX *= 0.70710678f;
				SuggestedY *= 0.70710678f;

			}

			Player.MoveTowards (SuggestedX + Player.GetX (), SuggestedY + Player.GetY ());

		}

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_TAB, false)) {
			System.err.println ("Stage Thread: " + Threader.RetrieveFPS ((byte) 0) + " FPS");
			System.err.println ("Management Thread: " + Threader.RetrieveFPS ((byte) 1) + " FPS");
			System.err.println ("Render Thread: " + Threader.RetrieveFPS ((byte) 2) + " FPS");
			System.err.println ("Update Thread: " + Threader.RetrieveFPS ((byte) 3) + " FPS");
			System.err.println ("Update Thread: " + Threader.RetrieveFPS ((byte) 4) + " FPS");
			System.err.println ("Update Thread: " + Threader.RetrieveFPS ((byte) 5) + " FPS");

		}

		if (KeyTracker.KeyPressed ((short) GLFW_KEY_ESCAPE, false)) {
			Application.Terminate (null);

		}

	}

	@Override
	public void UpdateTwo (long Elapsed) {

	}

	@Override
	public void UpdateThree (long Elapsed) {

	}

	@Override
	public void Terminate () {

	}

}