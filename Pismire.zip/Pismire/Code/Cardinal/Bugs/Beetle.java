package Cardinal.Bugs;

import Cardinal.Settings.Affinity;
import Cardinal.Settings.Context;
import Cardinal.World.Map;
import Elementals.Random;
import Elementals.Sprite;

public class Beetle {
	private float X, Y, VelocityX, VelocityY, PointX, PointY, Speed;
	private boolean IsMoving;
	private Sprite Model;

	public Beetle (float X, float Y) {
		this.Model = Affinity.t32e32 ().GetSprite (Affinity.GOLDENROD_TEXTURE);
		this.Model.SetLayer ((byte) 4);
		this.IsMoving = false;
		this.Speed = 0.3f;

		this.SetPosition (X, Y);

	}

	public void Update (long Elapsed) {
		if (IsMoving) {
			SetPosition (VelocityX * Context.ELAPSED_CONSTANT * Elapsed * Speed,
					VelocityY * Context.ELAPSED_CONSTANT * Elapsed * Speed);

			if (this.X > PointX - Context.ELAPSED_CONSTANT * Elapsed * 1.0f
					&& this.X < PointX + Context.ELAPSED_CONSTANT * Elapsed * 1.0f
					&& this.Y > PointY - Context.ELAPSED_CONSTANT * Elapsed * 1.0f
					&& this.Y < PointY + Context.ELAPSED_CONSTANT * Elapsed * 1.0f) {
				VelocityX = 0;
				VelocityY = 0;
				IsMoving = false;

			}

		}

		if (Random.Integer (0, 1000) == 1) {
			MoveTowards (Model.GetX () + Random.Float (-200.0f, 200.0f),
					Model.GetY () + Random.Float (-200.0f, 200.0f));

		}

	}

	private void PathToPoint () {
		if (IsMoving) {
			float DistanceX = PointX - this.X, DistanceY = PointY - this.Y;
			float Angle = (float) Math.atan2 (DistanceY, DistanceX);

			VelocityX = (float) Math.cos (Angle);
			VelocityY = (float) Math.sin (Angle);

			Model.SetAngle ((float) Math.toDegrees (-Angle) + 90.0f);

		}

	}

	private void SetPosition (float X, float Y) {
		this.X = X + this.X;
		this.Y = Y + this.Y;

		if (this.X > Map.GetBoundaryX () || this.X < 512.0f) {
			this.X -= X;

		} else {
			Model.SetX (this.X);

		}

		if (this.Y > Map.GetBoundaryY () || this.Y < 512.0f) {
			this.Y -= Y;

		} else {
			Model.SetY (this.Y);

		}

	}

	public void MoveTowards (float X, float Y) {
		this.PointX = X;
		this.PointY = Y;

		if (Math.abs (this.X - PointX) > 8.0f || Math.abs (this.Y - PointY) > 8.0f) {
			IsMoving = true;

		}

		PathToPoint ();

	}

	public float GetX () {
		return this.X;

	}

	public float GetY () {
		return this.Y;

	}

}