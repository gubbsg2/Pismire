package Cardinal.Settings;

public class Context {
	public static final boolean LIMIT_RENDERING = false;
	public static final boolean ENABLE_VYSNC = true;
	public static final byte BUG_NUMBER = 5;
	public static final short GADGET_NUMBER = 75;
	public static final short BATCH_SIZE = 2048;
	public static final int MAX_FRAMES = 150;
	public static final float SOUND_VOLUME = 1.0f;
	public static final float MUSIC_VOLUME = 1.0f;
	public static final float IMAGE_SCALING = 0.75f;
	public static final float ONE_OVER_SCALING = 1 / IMAGE_SCALING;
	public static final float ELAPSED_CONSTANT = 0.00000032f;
	public static final float BATCH_ERASE_FACTOR = 1.5f;
	public static final float BOUNDARY_X = 4096.0f;
	public static final float BOUNDARY_Y = 4096.0f;
	public static final String WINDOW_NAME = "Pismire";
	public static final String WINDOW_ICON = "Icon";
	public static final String SHADER_FILE = "Main.glsl";

}