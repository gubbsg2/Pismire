package Cardinal.Settings;

import Elementals.Atlas;

public class Affinity {
	public static final short WORKER_TEXTURE = 0;
	public static final short GOLDENROD_TEXTURE = 0;
	public static final short GROUND_TEXTURE = 0;
	public static final short CAVE_TEXTURE = 1;
	public static final short CURSOR_TEXTURE = 0;
	public static final short LEAF_TEXTURE = 1;
	public static final short TWIG_TEXTURE = 2;
	public static final short ROCK_TEXTURE = 3;
	public static final short MOUND_TEXTURE = 4;
	public static final short PUDDLE_TEXTURE = 5;
	public static final short ANTHILL_STAGES = 0;

	private static Atlas t32e32, t64e64, t128e128, t256e256, t512e512;

	public static void Design () {
		t32e32 = new Atlas ("32x32.png", (short) 1, (short) 32, (short) 32);
		t64e64 = new Atlas ("64x64.png", (short) 6, (short) 64, (short) 64);
		t128e128 = new Atlas ("128x128.png", (short) 25, (short) 128, (short) 128);
		t256e256 = new Atlas ("256x256.png", (short) 9, (short) 256, (short) 256);
		t512e512 = new Atlas ("512x512.png", (short) 2, (short) 512, (short) 512);

	}

	public static Atlas t32e32 () {
		return Affinity.t32e32;

	}

	public static Atlas t64e64 () {
		return Affinity.t64e64;

	}

	public static Atlas t128e128 () {
		return Affinity.t128e128;

	}

	public static Atlas t256256 () {
		return Affinity.t256e256;

	}

	public static Atlas t512e512 () {
		return Affinity.t512e512;

	}

}