package Elementals;

public class Timer {
	private boolean IsEnded;
	private int LoopCount, MaxLoop;
	private long StartTime, CurrentTime, EndTime;

	private Condition While = new Condition () {

		@Override
		public boolean Reaches () {
			return true;

		}

	};

	private Task OnRun = new Task () {

		@Override
		public void Run () {

		}

	};

	private Task OnLooped = new Task () {

		@Override
		public void Run () {

		}

	};

	private Task OnEnded = new Task () {

		@Override
		public void Run () {

		}

	};

	public Timer (long EndTime, int MaxLoop) {
		this.EndTime = EndTime;
		this.MaxLoop = MaxLoop;
		this.LoopCount = 0;
		this.StartTime = 0;
		this.CurrentTime = 0;
		this.IsEnded = true;

	}

	public void Design () {
		IsEnded = false;
		StartTime = System.nanoTime ();
		LoopCount = 0;
		Pulser.Link (this);

	}

	public void Terminate () {
		IsEnded = true;
		OnEnded.Run ();
		Pulser.Unlink (this);

	}

	public boolean IsEnded () {
		return IsEnded;

	}

	void Update () {
		if (While.Reaches ()) {
			OnRun.Run ();
			CurrentTime = System.nanoTime ();

			if (CurrentTime >= StartTime + EndTime && EndTime != 0) {
				LoopCount++;
				OnLooped.Run ();
				StartTime = System.nanoTime ();

				if (LoopCount >= MaxLoop && MaxLoop != 0) {
					Terminate ();

				}

			}

		}

	}

	public void SetWhile (Condition While) {
		this.While = While;

	}

	public void SetOnRun (Task OnRun) {
		this.OnRun = OnRun;

	}

	public void SetOnLooped (Task OnLooped) {
		this.OnLooped = OnLooped;

	}

	public void SetOnEnded (Task OnEnded) {
		this.OnEnded = OnEnded;

	}

}