package Elementals;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;

class ImageParser {
	private ByteBuffer Image;
	private short Width, Height;

	ByteBuffer Image () {
		return Image;

	}

	short Width () {
		return Width;

	}

	short Height () {
		return Height;

	}

	private ImageParser (ByteBuffer Image, short Width, short Height) {
		this.Image = Image;
		this.Width = Width;
		this.Height = Height;

	}

	static ImageParser LoadImage (String Path) {
		ByteBuffer Image = BufferUtils.createByteBuffer (0);
		short Width = 0, Height = 0;

		MemoryStack Stack = MemoryStack.stackPush ();

		IntBuffer Computer = Stack.mallocInt (1);
		IntBuffer BufferWidth = Stack.mallocInt (1);
		IntBuffer BufferHeight = Stack.mallocInt (1);

		Image = STBImage.stbi_load (Path, BufferWidth, BufferHeight, Computer, 4);

		if (Image == null) {
			FileRetrieveException Exception = new FileRetrieveException ("Error Parsing Image File");
			Application.Terminate (Exception);

		}

		Width = (short) BufferWidth.get ();
		Height = (short) BufferHeight.get ();

		return new ImageParser (Image, Width, Height);

	}

}