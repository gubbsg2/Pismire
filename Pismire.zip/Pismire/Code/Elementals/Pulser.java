package Elementals;

class Pulser {
	private static List<Timer> TimerList = new List<Timer> (Timer.class);;

	static void Link (Timer Item) {
		TimerList.Push (Item);

	}

	static void Unlink (Timer Item) {
		TimerList.Pull (Item);

	}

	static void Update (long Elapsed) {
		if (TimerList.Size () != 0) {
			for (short Index = 0; Index < TimerList.Size (); Index++) {
				TimerList.ItemAt (Index).Update ();

			}

		}

	}

}