package Elementals;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;

import org.joml.Vector2f;
import org.lwjgl.BufferUtils;

public class Face {
	private short[] SourceX, SourceY, SourceWidth, SourceHeight;

	private Font Face;
	private String Source;
	private Vector2f[][] CoordinateList;

	public Face (String Source) {
		this.Source = Source;

		Face = new Font (Source, Font.PLAIN, 64);

		BufferedImage Image = new BufferedImage (1, 1, BufferedImage.TYPE_INT_ARGB);
		Graphics2D Graphics = Image.createGraphics ();
		Graphics.setFont (Face);
		FontMetrics Metrics = Graphics.getFontMetrics ();

		short EstimatedWidth = (short) (Math.sqrt (Face.getNumGlyphs ()) * Face.getSize () + 1), Width = 0,
				Height = (short) Metrics.getHeight (), X = 0, Y = (short) (Metrics.getHeight () * 1.4f);

		SourceX = new short[Face.getNumGlyphs ()];
		SourceY = new short[Face.getNumGlyphs ()];
		SourceWidth = new short[Face.getNumGlyphs ()];
		SourceHeight = new short[Face.getNumGlyphs ()];

		CoordinateList = new Vector2f[Face.getNumGlyphs ()][4];

		for (short Index = 0; Index < Face.getNumGlyphs (); Index++) {
			if (Face.canDisplay (Index)) {
				SourceX[Index] = X;
				SourceY[Index] = Y;
				SourceWidth[Index] = (short) Metrics.charWidth (Index);
				SourceHeight[Index] = (short) (Metrics.getHeight ());

				Width = (short) Math.max (X + Metrics.charWidth (Index), Width);
				X += SourceWidth[Index];

				if (X > EstimatedWidth) {
					X = 0;
					Y += Metrics.getHeight () * 1.4f;
					Height += Metrics.getHeight () * 1.4f;

				}

			}

		}

		Height += Metrics.getHeight () * 1.4f;
		Graphics.dispose ();

		Image = new BufferedImage (Width, Height, BufferedImage.TYPE_INT_ARGB);
		Graphics = Image.createGraphics ();
		Graphics.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		Graphics.setFont (Face);
		Graphics.setColor (Color.WHITE);

		for (int Index = 0; Index < Face.getNumGlyphs (); Index++) {
			if (Face.canDisplay (Index)) {
				float XOne = SourceX[Index] / (float) Width;
				float XTwo = (SourceX[Index] + SourceWidth[Index]) / (float) Width;
				float YOne = (SourceY[Index] - SourceHeight[Index]) / (float) Height;
				float YTwo = SourceY[Index] / (float) Height;

				CoordinateList[Index][0] = new Vector2f (XTwo, YOne);
				CoordinateList[Index][1] = new Vector2f (XTwo, YTwo);
				CoordinateList[Index][2] = new Vector2f (XOne, YTwo);
				CoordinateList[Index][3] = new Vector2f (XOne, YOne);

				Graphics.drawString ("" + (char) Index, SourceX[Index], SourceY[Index]);

			}

		}

		Graphics.dispose ();

		int[] PixelList = new int[Image.getWidth () * Image.getHeight ()];
		Image.getRGB (0, 0, Image.getWidth (), Image.getHeight (), PixelList, 0, Image.getWidth ());

		ByteBuffer Buffer = BufferUtils.createByteBuffer (Image.getWidth () * Image.getHeight () * 4);

		for (int Index = 0; Index < Image.getHeight (); Index++) {
			for (int IndexTwo = 0; IndexTwo < Image.getWidth (); IndexTwo++) {
				byte Pixel = (byte) PixelList[Index * Image.getWidth () + IndexTwo];
				byte AlphaComponent = (byte) ((Pixel >> 24) & 0xFF);

				Buffer.put (AlphaComponent);
				Buffer.put (AlphaComponent);
				Buffer.put (AlphaComponent);
				Buffer.put (AlphaComponent);

			}

		}

		Buffer.flip ();

		Basin.SetTexture (new Texture (Buffer, Image, Source));

	}

	Vector2f[] GetCoordinateList (char Item) {
		return this.CoordinateList[Item];

	}

	String GetFace () {
		return this.Source;

	}

}