package Elementals;

public class Shaft {
	private Sprite Basic;
	private float Coordinate, CurrentValue, DesiredX;
	private short DesiredWidth;

	public Shaft (float X, float Y, Atlas Source, short Value, short Width, short Height) {
		this.Basic = Source.GetSprite (Value);
		this.Coordinate = Basic.GetCoordinateList ()[0].x;
		this.Basic.SetIsStatic (true);
		this.Basic.GetCoordinateList ()[0].x = 0.0f;
		this.Basic.GetCoordinateList ()[1].x = 0.0f;
		this.Basic.SetLayer ((byte) 7);
		this.Basic.SetY (Y);
		this.DesiredWidth = Width;
		this.DesiredX = X;
		this.Basic.SetHeight (Height);
		this.SetValue (0);
		this.CurrentValue = 0;

	}

	public void SetValue (float Value) {
		if (Value < 0.0f) {
			Value = 0.0f;

		}

		if (Value > 1.0f) {
			Value = 1.0f;

		}

		CurrentValue = Value;
		Basic.GetCoordinateList ()[0].x = Value * Coordinate;
		Basic.GetCoordinateList ()[1].x = Value * Coordinate;
		Basic.SetWidth ((short) (DesiredWidth * Value));
		Basic.SetX ((DesiredX + Basic.GetWidth () * 0.5f) - DesiredWidth * 0.5f);

	}

	public float GetValue () {
		return CurrentValue;

	}

	void SetOpen (boolean IsOpen) {
		if (IsOpen) {
			Basic.SetLayer ((byte) 0);

		} else {
			Basic.SetLayer ((byte) 0);

		}

	}

}