package Elementals;

import static org.lwjgl.glfw.GLFW.GLFW_KEY_UNKNOWN;
import static org.lwjgl.glfw.GLFW.GLFW_PRESS;
import static org.lwjgl.glfw.GLFW.GLFW_RELEASE;

public class KeyTracker {
	private static boolean[] KeyList = new boolean[350];

	public static void KeyCallback (long Window, int Key, int ScanCode, int Action, int Modifier) {
		if (Key != GLFW_KEY_UNKNOWN) {
			if (Action == GLFW_PRESS) {
				KeyList[Key] = true;

			} else if (Action == GLFW_RELEASE) {
				KeyList[Key] = false;

			}

		}

	}

	public static boolean KeyPressed (int Key, boolean Hold) {
		boolean Status = KeyList[Key];
		if (!Hold) {
			KeyList[Key] = false;

		}

		return Status;

	}

}