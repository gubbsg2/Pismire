package Elementals;

public class Range {
	float X;
	float Y;

	Range (float X, float Y) {
		this.X = X;
		this.Y = Y;

	}

}
