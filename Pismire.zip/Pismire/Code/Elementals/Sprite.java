package Elementals;

import org.joml.Vector2f;

public class Sprite {
	private float X, Y, TrueX, TrueY, Angle, R, G, B, A, Factor;
	private boolean IsStatic, IsFollowing;
	private short Width, Height;
	private byte Layer;

	private String Source;

	private Vector2f[] CoordinateList = {
			new Vector2f (1.0f, 1.0f), new Vector2f (1.0f, 0.0f), new Vector2f (0.0f, 0.0f),
			new Vector2f (0.0f, 1.0f)
	}, TransitionList = {
			new Vector2f (1.0f, 1.0f), new Vector2f (1.0f, 0.0f), new Vector2f (0.0f, 0.0f),
			new Vector2f (0.0f, 1.0f)
	};

	Sprite (String Source, float X, float Y) {
		this.Source = Source;
		this.X = X;
		this.Y = Y;
		this.TrueX = X;
		this.TrueY = Y;
		this.Angle = 0;
		this.Width = Basin.GetTexture (Source).GetWidth ();
		this.Height = Basin.GetTexture (Source).GetHeight ();
		this.R = 1.0f;
		this.G = 1.0f;
		this.B = 1.0f;
		this.A = 1.0f;
		this.Factor = 0.0f;
		this.Layer = 0;

	}

	public void Update () {
		float TempX = X;
		float TempY = Y;

		if (IsStatic) {
			TempX += Camera.GetX ();
			TempY += Camera.GetY ();

		}

		if (IsFollowing) {
			TempX += MouseTracker.GetX (true);
			TempY += MouseTracker.GetY (true);

		}

		TrueX = TempX;
		TrueY = TempY;

	}

	public void SetWidth (short Width) {
		this.Width = Width;

	}

	public void SetHeight (short Height) {
		this.Height = Height;

	}

	public void SetLayer (byte Layer) {
		this.Layer = Layer;

		Renderer.SetSprite (this);

	}

	public void SetX (float X) {
		this.X = X;
		this.TrueX = X;

	}

	public void SetY (float Y) {
		this.Y = Y;
		this.TrueY = Y;

	}

	void SetCoordinateList (Vector2f[] CoordinateList) {
		this.CoordinateList = CoordinateList;

	}

	public void SetAngle (float Angle) {
		this.Angle = Angle;

	}

	public void SetR (float R) {
		this.R = R;

	}

	public void SetG (float G) {
		this.G = G;

	}

	public void SetB (float B) {
		this.B = B;

	}

	public void SetA (float A) {
		this.A = A;

	}

	public void SetFactor (float Factor) {
		this.Factor = Factor;

	}

	void SetTransitionList (Vector2f[] TransitionList) {
		this.TransitionList = TransitionList;

	}

	public void SetIsStatic (boolean IsStatic) {
		this.IsStatic = IsStatic;

	}

	public void SetIsFollowing (boolean IsFollowing) {
		this.IsFollowing = IsFollowing;

	}

	public short GetWidth () {
		return this.Width;

	}

	public short GetHeight () {
		return this.Height;

	}

	public byte GetLayer () {
		return this.Layer;

	}

	public float GetX () {
		return this.X;

	}

	public float GetY () {
		return this.Y;

	}

	float GetTrueX () {
		return this.TrueX;

	}

	float GetTrueY () {
		return this.TrueY;

	}

	String GetTexture () {
		return this.Source;

	}

	Vector2f[] GetCoordinateList () {
		return this.CoordinateList;

	}

	public float GetR () {
		return this.R;

	}

	public float GetG () {
		return this.G;

	}

	public float GetB () {
		return this.B;

	}

	public float GetA () {
		return this.A;

	}

	public float GetAngle () {
		return this.Angle;

	}

	Vector2f[] GetTransitionList () {
		return this.TransitionList;

	}

	public float GetFactor () {
		return this.Factor;

	}

	public boolean GetIsStatic () {
		return this.IsStatic;

	}

	public boolean GetIsFollowing () {
		return this.IsFollowing;

	}

}