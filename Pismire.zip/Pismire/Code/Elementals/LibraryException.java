package Elementals;

class LibraryException extends Exception {
	LibraryException (String Mistake) {
		super (Mistake);

	}

	private static final long serialVersionUID = 1L;

}