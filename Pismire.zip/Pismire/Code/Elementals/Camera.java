package Elementals;

import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector3f;

import Cardinal.Settings.Context;

public class Camera {
	private static Matrix4f ProjectionMatrix, ViewMatrix;
	private static Vector2f Location;
	private static float X, Y;
	private static short Width, Height;

	static void Design (float X, float Y, short Width, short Height) {
		Camera.X = X;
		Camera.Y = Y;
		Camera.Width = (short) (Width * Context.IMAGE_SCALING);
		Camera.Height = (short) (Height * Context.IMAGE_SCALING);
		Camera.Location = new Vector2f (X, Y);
		Camera.ProjectionMatrix = new Matrix4f ();
		Camera.ViewMatrix = new Matrix4f ();
		AdjustProjection ();

	}

	static void Update () {
		Location.x = X;
		Location.y = Y;

	}

	private static void AdjustProjection () {
		ProjectionMatrix.identity ();
		ProjectionMatrix.ortho (0.0f, Width, 0.0f, Height, 0.0f, 100.0f);

	}

	static Matrix4f ViewMatrix () {
		Vector3f CameraFront = new Vector3f (0.0f, 0.0f, -1.0f);
		Vector3f CameraUp = new Vector3f (0.0f, 1.0f, 0.0f);

		ViewMatrix.identity ();
		ViewMatrix = ViewMatrix.lookAt (new Vector3f (Location.x, Location.y, 20.0f),
				CameraFront.add (Location.x, Location.y, 0.0f), CameraUp);

		return ViewMatrix;

	}

	static Matrix4f ProjectionMatrix () {
		return ProjectionMatrix;

	}

	public static void SetX (float X) {
		Camera.X = X;

	}

	public static void SetY (float Y) {
		Camera.Y = Y;

	}

	public static float GetX () {
		return Camera.X;

	}

	public static float GetY () {
		return Camera.Y;

	}

}