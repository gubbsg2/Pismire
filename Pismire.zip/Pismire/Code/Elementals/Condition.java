package Elementals;

public abstract class Condition {
	abstract boolean Reaches ();

}