package Elementals;

public class Basin {
	private static List<String> TexturePathList, RootPathList;
	private static List<Texture> TextureList;
	private static List<Root> RootList;

	static void Design () {
		TexturePathList = new List<String> (String.class);
		TextureList = new List<Texture> (Texture.class);
		RootPathList = new List<String> (String.class);
		RootList = new List<Root> (Root.class);

	}

	static void SetTexture (String Source) {
		if (!TexturePathList.Contains (Source)) {
			Texture Item = new Texture (Source);
			TexturePathList.Push (Source);
			TextureList.Push (Item);

		}

	}

	static void SetTexture (Texture Item) {
		if (!TexturePathList.Contains (Item.GetSource ())) {
			TexturePathList.Push (Item.GetSource ());
			TextureList.Push (Item);

		}

	}

	static void SetRoot (String Source) {
		if (!RootPathList.Contains (Source)) {
			Root Item = new Root (Source);
			RootPathList.Push (Source);
			RootList.Push (Item);

		}

	}

	static void Terminate () {
		for (short Index = 0; Index < TextureList.Size (); Index++) {
			TextureList.ItemAt (Index).Terminate ();

		}

	}

	static Texture GetTexture (String Source) {
		return TextureList.ItemAt (TexturePathList.IndexOf (Source));

	}

	static Root GetRoot (String Source) {
		return RootList.ItemAt (RootPathList.IndexOf (Source));

	}

}