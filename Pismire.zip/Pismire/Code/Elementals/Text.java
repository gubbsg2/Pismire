package Elementals;

public class Text {
	private short Size, X, Y;
	private float R, G, B, A;

	private List<Sprite> SpriteList;
	private Face Core;
	private String Source;

	public Text (String Source, short X, short Y, short Size, float R, float G, float B, float A) {
		this.Size = Size;
		this.Core = new Face (Source);
		this.SpriteList = new List<Sprite> (Sprite.class);
		this.Source = Source;
		this.X = X;
		this.Y = Y;
		this.R = R;
		this.G = G;
		this.B = B;
		this.A = A;

	}

	public void SetText (String Text) {
		SpriteList.Clear ();
		short Total = (short) (0.5f * Text.length ());

		for (short Index = 0; Index < Text.length (); Index++) {
			Sprite Item = new Sprite (Source, X + (Size * (Index - Total)), Y);

			Item.SetIsStatic (true);
			Item.SetWidth (Size);
			Item.SetHeight (Size);
			Item.SetCoordinateList (Core.GetCoordinateList (Text.charAt (Index)));
			Item.SetLayer ((byte) 8);
			Item.SetR (R);
			Item.SetG (G);
			Item.SetB (B);
			Item.SetA (A);

			SpriteList.Push (Item);

		}

	}

}