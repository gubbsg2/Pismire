package Elementals;

public class Board {
	private Range RangeX, RangeY;
	private Sprite Basic;
	private List<Board> BoardList;
	private List<Hook> HookList;
	private List<Shaft> ShaftList;
	private List<Rod> RodList;

	public Board (float X, float Y, Atlas Source, short Value, short Width, short Height) {
		this.Basic = Source.GetSprite (Value);
		this.Basic.SetIsStatic (true);
		this.Basic.SetLayer ((byte) 7);
		this.Basic.SetWidth (Width);
		this.Basic.SetHeight (Height);
		this.RangeX = new Range (X - (0.5f * Basic.GetWidth ()), X + (0.5f * Basic.GetWidth ()));
		this.RangeY = new Range (Y - (0.5f * Basic.GetHeight ()), Y + (0.5f * Basic.GetHeight ()));
		this.Basic.SetX (X);
		this.Basic.SetY (Y);
		this.BoardList = new List<Board> (Board.class);
		this.HookList = new List<Hook> (Hook.class);
		this.ShaftList = new List<Shaft> (Shaft.class);
		this.RodList = new List<Rod> (Rod.class);

		Device.SetBoard (this);

	}

	void Update (float X, float Y) {
		if (X >= RangeX.X && X <= RangeX.Y && Y >= RangeY.X && Y <= RangeY.Y) {
			for (short Index = 0; Index < BoardList.Size (); Index++) {
				BoardList.ItemAt (Index).Update (X, Y);

			}

			for (short Index = 0; Index < HookList.Size (); Index++) {
				HookList.ItemAt (Index).Update (X, Y);

			}

			for (short Index = 0; Index < RodList.Size (); Index++) {
				RodList.ItemAt (Index).Update (X, Y);

			}

		}

	}

	public void SetBoard (Board Item) {
		BoardList.Push (Item);
		Device.SetBoard (Item);

	}

	public void SetHook (Hook Item) {
		HookList.Push (Item);

	}

	public void SetShaft (Shaft Item) {
		ShaftList.Push (Item);

	}

	public void SetRod (Rod Item) {
		RodList.Push (Item);

	}

	public void SetOpen (boolean IsOpen) {
		if (IsOpen) {
			Basic.SetLayer ((byte) 7);

			for (short Index = 0; Index < RodList.Size (); Index++) {
				RodList.ItemAt (Index).SetOpen (true);

			}

			for (short Index = 0; Index < ShaftList.Size (); Index++) {
				ShaftList.ItemAt (Index).SetOpen (true);

			}

			for (short Index = 0; Index < HookList.Size (); Index++) {
				HookList.ItemAt (Index).SetOpen (true);

			}

			for (short Index = 0; Index < BoardList.Size (); Index++) {
				BoardList.ItemAt (Index).SetOpen (true);

			}

		} else {
			Basic.SetLayer ((byte) 0);

			for (short Index = 0; Index < RodList.Size (); Index++) {
				RodList.ItemAt (Index).SetOpen (false);

			}

			for (short Index = 0; Index < ShaftList.Size (); Index++) {
				ShaftList.ItemAt (Index).SetOpen (false);

			}

			for (short Index = 0; Index < HookList.Size (); Index++) {
				HookList.ItemAt (Index).SetOpen (false);

			}

			for (short Index = 0; Index < BoardList.Size (); Index++) {
				BoardList.ItemAt (Index).SetOpen (false);

			}

		}

	}

	boolean IsOpen () {
		return Basic.GetLayer () != 0;

	}

}