package Elementals;

class FileRetrieveException extends Exception {
	FileRetrieveException (String Mistake) {
		super (Mistake);

	}

	private static final long serialVersionUID = 1L;

}