package Elementals;

class InvalidTypeException extends Exception {
	private static final long serialVersionUID = 1L;

	InvalidTypeException (String Mistake) {
		super (Mistake);

	}

}
