package Elementals;

class OperatorReturnException extends Exception {
	OperatorReturnException (String Mistake) {
		super (Mistake);

	}

	private static final long serialVersionUID = 1L;

}