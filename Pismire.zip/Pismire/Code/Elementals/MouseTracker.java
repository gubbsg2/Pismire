package Elementals;

import static org.lwjgl.glfw.GLFW.GLFW_PRESS;
import static org.lwjgl.glfw.GLFW.GLFW_RELEASE;

import Cardinal.Settings.Context;

public class MouseTracker {
	private static boolean[] ButtonList = new boolean[3];
	private static float X, Y;

	public static void ButtonCallback (long Window, int Button, int Action, int Modifier) {

		if (Action == GLFW_PRESS) {
			ButtonList[Button] = true;

		} else if (Action == GLFW_RELEASE) {
			ButtonList[Button] = false;

		}

	}

	public static void PositionCallback (long Window, double NewX, double NewY) {
		X = (float) NewX;
		Y = (float) NewY - 2;

	}

	public static boolean ButtonPressed (short Button, boolean Hold) {
		boolean Status = ButtonList[Button];

		if (!Hold) {
			ButtonList[Button] = false;

		}

		return Status;

	}

	public static float GetX (boolean Plain) {
		if (Plain) {
			return X * Context.IMAGE_SCALING;

		} else {
			return X * Context.IMAGE_SCALING + Camera.GetX ();

		}

	}

	public static float GetY (boolean Plain) {
		if (Plain) {
			return 1080.0f - Y * Context.IMAGE_SCALING;

		} else {
			return 1080.0f - Y * Context.IMAGE_SCALING + Camera.GetY ();

		}

	}

}