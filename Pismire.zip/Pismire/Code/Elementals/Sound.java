package Elementals;

import static org.lwjgl.openal.AL10.AL_FALSE;
import static org.lwjgl.openal.AL10.AL_GAIN;
import static org.lwjgl.openal.AL10.AL_LOOPING;
import static org.lwjgl.openal.AL10.alSourcef;
import static org.lwjgl.openal.AL10.alSourcei;

import Cardinal.Settings.Context;

public class Sound {
	private String Audio;

	public Sound (String Path) {
		Audio = Path;
		alSourcei (Basin.GetRoot (Audio).GetSource (), AL_LOOPING, AL_FALSE);
		alSourcef (Basin.GetRoot (Audio).GetSource (), AL_GAIN, Context.SOUND_VOLUME);

	}

	public void Play () {
		Basin.GetRoot (Audio).Play ();

	}

}