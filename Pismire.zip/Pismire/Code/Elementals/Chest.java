package Elementals;

class Chest {
	private static List<Music> MusicList;

	static void Design () {
		MusicList = new List<Music> (Music.class);

	}

	static void Update (long Elapsed) {
		for (short Index = 0; Index < MusicList.Size (); Index++) {
			MusicList.ItemAt (Index).Update (Elapsed);

		}

	}

	static void Terminate () {
		for (short Index = 0; Index < MusicList.Size (); Index++) {
			Basin.GetRoot (MusicList.ItemAt (Index).GetAudio ()).Terminate ();

		}

	}

	static void SetMusic (Music Item) {
		Chest.MusicList.Push (Item);

	}

}