package Elementals;

import Cardinal.Structure;

public class Application {
	private static Structure Game;

	static void Design (String Name, String Icon) {
		Game = new Structure ();
		Threader.Start (Name, Icon, Game);

	}

	public static void Terminate (Exception Mistake) {
		Stage.SetShouldClose ();

		if (Mistake != null) {
			Mistake.printStackTrace ();

		}

	}

}