package Elementals;

import static org.lwjgl.glfw.GLFW.GLFW_CONTEXT_VERSION_MAJOR;
import static org.lwjgl.glfw.GLFW.GLFW_CONTEXT_VERSION_MINOR;
import static org.lwjgl.glfw.GLFW.GLFW_CURSOR;
import static org.lwjgl.glfw.GLFW.GLFW_CURSOR_HIDDEN;
import static org.lwjgl.glfw.GLFW.GLFW_DECORATED;
import static org.lwjgl.glfw.GLFW.GLFW_FALSE;
import static org.lwjgl.glfw.GLFW.GLFW_OPENGL_CORE_PROFILE;
import static org.lwjgl.glfw.GLFW.GLFW_OPENGL_PROFILE;
import static org.lwjgl.glfw.GLFW.GLFW_VISIBLE;
import static org.lwjgl.glfw.GLFW.glfwCreateWindow;
import static org.lwjgl.glfw.GLFW.glfwDestroyWindow;
import static org.lwjgl.glfw.GLFW.glfwGetPrimaryMonitor;
import static org.lwjgl.glfw.GLFW.glfwGetVideoMode;
import static org.lwjgl.glfw.GLFW.glfwInit;
import static org.lwjgl.glfw.GLFW.glfwPollEvents;
import static org.lwjgl.glfw.GLFW.glfwSetCursorPosCallback;
import static org.lwjgl.glfw.GLFW.glfwSetInputMode;
import static org.lwjgl.glfw.GLFW.glfwSetKeyCallback;
import static org.lwjgl.glfw.GLFW.glfwSetMouseButtonCallback;
import static org.lwjgl.glfw.GLFW.glfwSetWindowIcon;
import static org.lwjgl.glfw.GLFW.glfwSetWindowShouldClose;
import static org.lwjgl.glfw.GLFW.glfwShowWindow;
import static org.lwjgl.glfw.GLFW.glfwTerminate;
import static org.lwjgl.glfw.GLFW.glfwWindowHint;
import static org.lwjgl.glfw.GLFW.glfwWindowShouldClose;
import static org.lwjgl.openal.AL.createCapabilities;
import static org.lwjgl.openal.ALC.createCapabilities;
import static org.lwjgl.openal.ALC10.ALC_DEFAULT_DEVICE_SPECIFIER;
import static org.lwjgl.openal.ALC10.alcCloseDevice;
import static org.lwjgl.openal.ALC10.alcCreateContext;
import static org.lwjgl.openal.ALC10.alcDestroyContext;
import static org.lwjgl.openal.ALC10.alcGetString;
import static org.lwjgl.openal.ALC10.alcMakeContextCurrent;
import static org.lwjgl.openal.ALC10.alcOpenDevice;

import org.lwjgl.glfw.Callbacks;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.openal.ALCCapabilities;
import org.lwjgl.openal.ALCapabilities;
import org.lwjgl.stb.STBImage;

class Stage {
	private static long StageHandle, AudioContext, DeviceContext;
	private static short Width, Height;
	private static boolean IsStarted = false, IsClosing = false;

	static void Initialize (String Name, String Source) {
		if (!glfwInit ()) {
			LibraryException Exception = new LibraryException ("GLFW Could Not Be Loaded");
			Application.Terminate (Exception);

		}

		glfwWindowHint (GLFW_VISIBLE, GLFW_FALSE);
		glfwWindowHint (GLFW_DECORATED, GLFW_FALSE);
		glfwWindowHint (GLFW_CONTEXT_VERSION_MAJOR, 3);
		glfwWindowHint (GLFW_CONTEXT_VERSION_MINOR, 2);
		glfwWindowHint (GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

		GLFWVidMode VideoMode = glfwGetVideoMode (glfwGetPrimaryMonitor ());
		Width = (short) VideoMode.width ();
		Height = (short) VideoMode.height ();

		String DefaultDeviceName = alcGetString (0, ALC_DEFAULT_DEVICE_SPECIFIER);
		DeviceContext = alcOpenDevice (DefaultDeviceName);
		int[] AttributeList = {
				0
		};

		AudioContext = alcCreateContext (DeviceContext, AttributeList);
		alcMakeContextCurrent (AudioContext);
		ALCCapabilities SoundCapabilities = createCapabilities (DeviceContext);
		ALCapabilities DeviceCapabilities = createCapabilities (SoundCapabilities);

		if (!DeviceCapabilities.OpenAL11) {
			LibraryException Exception = new LibraryException ("OpenAL Could Not Be Loaded");
			Application.Terminate (Exception);

		}

		StageHandle = glfwCreateWindow (Width, Height, Name, 0, 0);

		if (StageHandle == 0) {
			OperatorReturnException Exception = new OperatorReturnException ("Failed to Create the Window");
			Application.Terminate (Exception);

		}

		glfwSetMouseButtonCallback (StageHandle, MouseTracker::ButtonCallback);
		glfwSetCursorPosCallback (StageHandle, MouseTracker::PositionCallback);
		glfwSetKeyCallback (StageHandle, KeyTracker::KeyCallback);

		glfwShowWindow (StageHandle);
		IsStarted = true;

		STBImage.stbi_set_flip_vertically_on_load (false);
		final ImageParser Resource = ImageParser.LoadImage ("Assets/Extra/" + Source + ".png");
		GLFWImage Icon = GLFWImage.malloc ();
		GLFWImage.Buffer IconSet = GLFWImage.malloc (1);
		Icon.set (Resource.Width (), Resource.Height (), Resource.Image ());
		IconSet.put (0, Icon);
		glfwSetWindowIcon (StageHandle, IconSet);
		STBImage.stbi_set_flip_vertically_on_load (true);

		glfwSetInputMode (StageHandle, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

	}

	static void Update (long Elapsed) {
		glfwPollEvents ();

	}

	static void Terminate () {
		alcDestroyContext (AudioContext);
		alcCloseDevice (DeviceContext);

		glfwSetWindowShouldClose (StageHandle, true);
		Callbacks.glfwFreeCallbacks (StageHandle);
		glfwDestroyWindow (StageHandle);
		glfwTerminate ();

	}

	static void SetShouldClose () {
		glfwSetWindowShouldClose (StageHandle, true);

	}

	static boolean GetShouldClose () {
		if (StageHandle != 0) {
			boolean ShouldClose = glfwWindowShouldClose (StageHandle) || IsClosing;

			if (ShouldClose) {
				IsClosing = true;

			}

			return ShouldClose;

		}

		return false;

	}

	static long Handle () {
		return StageHandle;

	}

	static short GetWidth () {
		return Stage.Width;

	}

	static short GetHeight () {
		return Stage.Height;

	}

	static boolean GetStarted () {
		return Stage.IsStarted;

	}

}