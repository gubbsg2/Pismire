package Elementals;

public abstract class Actionable {
	public abstract void Design ();

	public abstract void UpdateOne (long Elapsed);

	public abstract void UpdateTwo (long Elapsed);

	public abstract void UpdateThree (long Elapsed);

	public abstract void Terminate ();

}