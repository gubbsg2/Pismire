package Elementals;

import Cardinal.Structure;
import Cardinal.Settings.Context;

public class Threader {
	private static Runner StageThread, ManagementThread, RenderThread, GameThreadOne, GameThreadTwo,
			GameThreadThree;
	private static long LastTimeOne = System.nanoTime (), CurrentTimeOne = System.nanoTime (),
			LastTimeTwo = System.nanoTime (), CurrentTimeTwo = System.nanoTime (),
			LastTimeThree = System.nanoTime (), CurrentTimeThree = System.nanoTime (),
			LastTimeFour = System.nanoTime (), CurrentTimeFour = System.nanoTime (),
			LastTimeFive = System.nanoTime (), CurrentTimeFive = System.nanoTime (),
			LastTimeSix = System.nanoTime (), CurrentTimeSix = System.nanoTime ();
	private static long ElapsedOne, ElapsedTwo, ElapsedThree, ElapsedFour, ElapsedFive, ElapsedSix;

	static void Start (String Name, String Icon, Structure Game) {
		StageThread = new Runner ();

		StageThread.SetUpdate (new Task () {

			@Override
			public void Run () {
				if (!Stage.GetStarted ()) {
					Stage.Initialize (Name, Icon);

				}

				LastTimeOne = CurrentTimeOne;
				CurrentTimeOne = System.nanoTime ();
				ElapsedOne = (long) (CurrentTimeOne - LastTimeOne);

				Stage.Update (ElapsedOne);

			}

		});

		StageThread.SetTerminate (new Task () {

			@Override
			public void Run () {
				Stage.Terminate ();
				Application.Terminate (null);

			}

		});

		Thread StageRun = new Thread (StageThread);
		StageRun.start ();

		ManagementThread = new Runner ();

		ManagementThread.SetUpdate (new Task () {

			@Override
			public void Run () {
				LastTimeTwo = CurrentTimeTwo;
				CurrentTimeTwo = System.nanoTime ();
				ElapsedTwo = (long) (CurrentTimeTwo - LastTimeTwo);

				Chest.Update (ElapsedTwo);
				Pulser.Update (ElapsedTwo);
				Device.Update ();

			}

		});

		ManagementThread.SetTerminate (new Task () {

			@Override
			public void Run () {
				Chest.Terminate ();
				Application.Terminate (null);

			}

		});

		RenderThread = new Runner ();

		RenderThread.SetLimited (Context.LIMIT_RENDERING);
		RenderThread.SetUpdate (new Task () {

			@Override
			public void Run () {
				LastTimeThree = CurrentTimeThree;
				CurrentTimeThree = System.nanoTime ();
				ElapsedThree = (long) (CurrentTimeThree - LastTimeThree);

				if (Stage.Handle () != 0) {
					if (!Renderer.GetStarted ()) {
						Renderer.Initialize ();
						Game.Design ();
						Renderer.SetStarted (true);

					}

					Renderer.Update (ElapsedThree);

				}

			}

		});

		RenderThread.SetTerminate (new Task () {

			@Override
			public void Run () {
				Renderer.Terminate ();
				Application.Terminate (null);

			}

		});

		GameThreadOne = new Runner ();

		GameThreadOne.SetUpdate (new Task () {

			@Override
			public void Run () {
				if (Renderer.GetStarted ()) {
					LastTimeFour = CurrentTimeFour;
					CurrentTimeFour = System.nanoTime ();
					ElapsedFour = (long) (CurrentTimeFour - LastTimeFour);
					Game.UpdateOne (ElapsedFour);

				}

			}

		});

		GameThreadTwo = new Runner ();

		GameThreadTwo.SetUpdate (new Task () {

			@Override
			public void Run () {
				if (Renderer.GetStarted ()) {
					LastTimeFive = CurrentTimeFive;
					CurrentTimeFive = System.nanoTime ();
					ElapsedFive = (long) (CurrentTimeFive - LastTimeFive);
					Game.UpdateTwo (ElapsedFive);

				}

			}

		});

		GameThreadThree = new Runner ();

		GameThreadThree.SetUpdate (new Task () {

			@Override
			public void Run () {
				if (Renderer.GetStarted ()) {
					LastTimeSix = CurrentTimeSix;
					CurrentTimeSix = System.nanoTime ();

					ElapsedSix = (long) (CurrentTimeSix - LastTimeSix);
					Game.UpdateThree (ElapsedSix);

				}

			}

		});

		GameThreadOne.SetTerminate (new Task () {

			@Override
			public void Run () {
				Game.Terminate ();
				Application.Terminate (null);

			}

		});

		Thread ManagementRun = new Thread (ManagementThread);
		Thread RenderRun = new Thread (RenderThread);
		Thread GameRunOne = new Thread (GameThreadOne);
		Thread GameRunTwo = new Thread (GameThreadTwo);
		Thread GameRunThree = new Thread (GameThreadThree);

		Chest.Design ();
		Basin.Design ();
		Device.Design ();

		ManagementRun.start ();
		RenderRun.start ();
		GameRunOne.start ();
		GameRunTwo.start ();
		GameRunThree.start ();

	}

	public static int RetrieveFPS (byte Thread) {
		switch (Thread) {
			case 0:
				return StageThread.GetFPS ();

			case 1:
				return ManagementThread.GetFPS ();

			case 2:
				return RenderThread.GetFPS ();

			case 3:
				return GameThreadOne.GetFPS ();

			case 4:
				return GameThreadTwo.GetFPS ();

			case 5:
				return GameThreadThree.GetFPS ();

			default:
				return -1;

		}

	}

}