package Elementals;

class BrokenCodeException extends Exception {
	BrokenCodeException (String Mistake) {
		super (Mistake);

	}

	private static final long serialVersionUID = 1L;

}