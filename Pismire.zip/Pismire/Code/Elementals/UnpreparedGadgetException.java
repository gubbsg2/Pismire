package Elementals;

class UnpreparedGadgetException extends Exception {
	UnpreparedGadgetException (String Mistake) {
		super (Mistake);

	}

	private static final long serialVersionUID = 1L;

}