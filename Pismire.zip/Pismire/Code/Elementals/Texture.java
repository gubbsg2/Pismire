package Elementals;

import static org.lwjgl.opengl.GL11.GL_LINEAR;
import static org.lwjgl.opengl.GL11.GL_NEAREST;
import static org.lwjgl.opengl.GL11.GL_REPEAT;
import static org.lwjgl.opengl.GL11.GL_RGB;
import static org.lwjgl.opengl.GL11.GL_RGB8;
import static org.lwjgl.opengl.GL11.GL_RGBA;
import static org.lwjgl.opengl.GL11.GL_RGBA8;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_MAG_FILTER;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_MIN_FILTER;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_WRAP_S;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_WRAP_T;
import static org.lwjgl.opengl.GL11.GL_UNSIGNED_BYTE;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glDeleteTextures;
import static org.lwjgl.opengl.GL11.glGenTextures;
import static org.lwjgl.opengl.GL11.glTexParameteri;

import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL46;
import org.lwjgl.stb.STBImage;

class Texture {
	private short Width, Height;
	private int TextureID;

	private String Source;
	private ByteBuffer Image;

	Texture (String Source) {
		this.Source = Source;

		TextureID = glGenTextures ();
		glBindTexture (GL_TEXTURE_2D, TextureID);

		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		IntBuffer WidthBuffer = BufferUtils.createIntBuffer (1);
		IntBuffer HeightBuffer = BufferUtils.createIntBuffer (1);
		IntBuffer ChannelBuffer = BufferUtils.createIntBuffer (1);

		Image = STBImage.stbi_load ("Assets/Pictures/" + Source, WidthBuffer, HeightBuffer, ChannelBuffer, 0);

		Width = (short) WidthBuffer.get (0);
		Height = (short) HeightBuffer.get (0);

		byte ChannelCount = (byte) ChannelBuffer.get (0);

		if (Image != null) {
			if (ChannelCount == 3) {
				GL46.glTexImage2D (GL_TEXTURE_2D, 0, GL_RGB8, Width, Height, 0, GL_RGB,
						GL_UNSIGNED_BYTE, Image);

			} else {
				GL46.glTexImage2D (GL_TEXTURE_2D, 0, GL_RGBA8, Width, Height, 0, GL_RGBA,
						GL_UNSIGNED_BYTE, Image);

			}

		} else {
			OperatorReturnException Exception = new OperatorReturnException ("Failed to Create Image");
			Application.Terminate (Exception);

		}

		STBImage.stbi_image_free (Image);

	}

	Texture (ByteBuffer Buffer, BufferedImage Image, String Source) {
		this.Width = (short) Image.getWidth ();
		this.Height = (short) Image.getHeight ();
		this.Source = Source;
		this.Image = Buffer;

		TextureID = glGenTextures ();
		glBindTexture (GL_TEXTURE_2D, TextureID);

		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		GL46.glTexImage2D (GL_TEXTURE_2D, 0, GL_RGBA8, Width, Height, 0, GL_RGBA , GL_UNSIGNED_BYTE, Buffer);

	}

	void Bind () {
		glBindTexture (GL_TEXTURE_2D, TextureID);

	}

	void Terminate () {
		glDeleteTextures (TextureID);

	}

	short GetWidth () {
		return this.Width;

	}

	short GetHeight () {
		return this.Height;

	}

	String GetSource () {
		return this.Source;

	}

}