package Elementals;

import java.lang.reflect.Array;

public class List<Type> {
	private Class<?> Class;
	private int Size;
	private Type[] Internal;

	@SuppressWarnings("unchecked")
	public List (Class<?> Type) {
		this.Class = Type;
		this.Size = 0;
		this.Internal = (Type[]) Array.newInstance (Class, Size);

	}

	@SuppressWarnings("unchecked")
	public void Push (Type Item) {
		Size++;
		Type[] Temporary = (Type[]) Array.newInstance (Class, Size);

		if (Temporary.length != Size) {
			Temporary = (Type[]) Array.newInstance (Class, Size);

		}

		for (int Index = 0; Index < Internal.length; Index++) {
			Temporary[Index] = Internal[Index];

		}

		Temporary[Size - 1] = Item;
		Internal = Temporary;

	}

	@SuppressWarnings("unchecked")
	public void Pull (Type Item) {
		Size--;
		boolean IsFound = false;
		Type[] Temporary = (Type[]) Array.newInstance (Class, Size);

		for (short Index = 0; Index < Internal.length; Index++) {
			if (Internal[Index] == Item) {
				IsFound = true;

			}

			if (!IsFound) {
				Temporary[Index] = Internal[Index];

			} else {
				Temporary[Index - 1] = Internal[Index];

			}

		}

		Internal = Temporary;

	}

	public Type ItemAt (short Index) {
		return Internal[Index];

	}

	public short IndexOf (Type Item) {
		for (short Index = 0; Index < Internal.length; Index++) {
			if (Internal[Index] == Item) {
				return Index;

			}

		}

		return -1;

	}

	public boolean Contains (Type Item) {
		if (IndexOf (Item) != -1) {
			return true;

		}

		return false;

	}

	public int Size () {
		return Size;

	}

	@SuppressWarnings("unchecked")
	public void Clear () {
		Size = 0;
		Internal = (Type[]) Array.newInstance (Class, Size);

	}

}