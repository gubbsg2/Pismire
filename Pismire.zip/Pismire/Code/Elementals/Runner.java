package Elementals;

import Cardinal.Settings.Context;

class Runner implements Runnable {
	private int FPS = 0;
	private int Temporary = 0;
	private long StartTime = System.nanoTime (), CurrentTime = System.nanoTime ();
	private final float ELAPSED_MUST = 849.9787f / Context.MAX_FRAMES;
	private boolean IsLimited = true;

	private Task Update;
	private Task Terminate = new Task () {

		@Override
		public void Run () {
			Application.Terminate (null);

		}

	};

	public void run () {
		while (!Stage.GetShouldClose ()) {
			if (IsLimited) {
				try {
					Thread.sleep ((long) Math.floor (ELAPSED_MUST));

				} catch (InterruptedException Hoarder) {

				}

			}

			Update.Run ();
			Temporary++;

			CurrentTime = System.nanoTime ();

			if (CurrentTime - StartTime > 1000000000) {
				StartTime = System.nanoTime ();
				FPS = Temporary;
				Temporary = 0;

			}

		}

		Terminate.Run ();

	}

	void SetUpdate (Task Update) {
		this.Update = Update;

	}

	void SetTerminate (Task Terminate) {
		this.Terminate = Terminate;

	}

	void SetLimited (boolean IsLimited) {
		this.IsLimited = IsLimited;

	}

	int GetFPS () {
		return this.FPS;

	}

}