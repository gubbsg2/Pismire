package Elementals;

import Cardinal.Settings.Context;

public class Launcher {
	public static void main (String[] Code) {
		try {
			Application.Design (Context.WINDOW_NAME, Context.WINDOW_ICON);

		} catch (Exception Hoarder) {
			Application.Terminate (Hoarder);

		}

	}

}