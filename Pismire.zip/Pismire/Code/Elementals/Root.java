package Elementals;

import static org.lwjgl.openal.AL10.AL_BUFFER;
import static org.lwjgl.openal.AL10.AL_FORMAT_MONO16;
import static org.lwjgl.openal.AL10.AL_FORMAT_STEREO16;
import static org.lwjgl.openal.AL10.AL_POSITION;
import static org.lwjgl.openal.AL10.alBufferData;
import static org.lwjgl.openal.AL10.alDeleteBuffers;
import static org.lwjgl.openal.AL10.alDeleteSources;
import static org.lwjgl.openal.AL10.alGenBuffers;
import static org.lwjgl.openal.AL10.alGenSources;
import static org.lwjgl.openal.AL10.alSourcePlay;
import static org.lwjgl.openal.AL10.alSourceStop;
import static org.lwjgl.openal.AL10.alSourcei;
import static org.lwjgl.system.MemoryStack.stackMallocInt;
import static org.lwjgl.system.MemoryStack.stackPop;
import static org.lwjgl.system.MemoryStack.stackPush;

import java.nio.IntBuffer;
import java.nio.ShortBuffer;

import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.libc.LibCStdlib;

public class Root {
	private int BufferID, SourceID;

	Root (String Source) {
		stackPush ();
		IntBuffer ChannelBuffer = stackMallocInt (1);

		stackPush ();
		IntBuffer SampleRateBuffer = stackMallocInt (1);

		ShortBuffer RawAudioBuffer = STBVorbis.stb_vorbis_decode_filename ("Assets/Audio/" + Source,
				ChannelBuffer, SampleRateBuffer);

		if (RawAudioBuffer == null) {
			stackPop ();
			stackPop ();

			OperatorReturnException Exception = new OperatorReturnException ("Failed to Load Sound");
			Application.Terminate (Exception);

		}

		byte Channel = (byte) ChannelBuffer.get ();
		int SampleRate = SampleRateBuffer.get ();

		stackPop ();
		stackPop ();

		int Format = -1;

		if (Channel == 1) {
			Format = AL_FORMAT_MONO16;

		} else if (Channel == 2) {
			Format = AL_FORMAT_STEREO16;

		}

		BufferID = alGenBuffers ();
		alBufferData (BufferID, Format, RawAudioBuffer, SampleRate);

		SourceID = alGenSources ();
		alSourcei (SourceID, AL_BUFFER, BufferID);
		alSourcei (SourceID, AL_POSITION, 0);

		LibCStdlib.free (RawAudioBuffer);

	}

	void Play () {
		alSourcePlay (SourceID);

	}

	void Stop () {
		alSourceStop (SourceID);

	}

	void Terminate () {
		alDeleteSources (SourceID);
		alDeleteBuffers (BufferID);

	}

	int GetSource () {
		return this.SourceID;

	}

}