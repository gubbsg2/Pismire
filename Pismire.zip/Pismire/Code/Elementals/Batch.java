package Elementals;

import static org.lwjgl.opengl.GL11.GL_FLOAT;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.GL_TRIANGLES;
import static org.lwjgl.opengl.GL11.GL_UNSIGNED_INT;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glDrawElements;
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;
import static org.lwjgl.opengl.GL13.glActiveTexture;
import static org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER;
import static org.lwjgl.opengl.GL15.GL_DYNAMIC_DRAW;
import static org.lwjgl.opengl.GL15.GL_ELEMENT_ARRAY_BUFFER;
import static org.lwjgl.opengl.GL15.GL_STATIC_DRAW;
import static org.lwjgl.opengl.GL15.glBindBuffer;
import static org.lwjgl.opengl.GL15.glBufferData;
import static org.lwjgl.opengl.GL15.glBufferSubData;
import static org.lwjgl.opengl.GL15.glGenBuffers;
import static org.lwjgl.opengl.GL20.glDisableVertexAttribArray;
import static org.lwjgl.opengl.GL20.glEnableVertexAttribArray;
import static org.lwjgl.opengl.GL20.glVertexAttribPointer;
import static org.lwjgl.opengl.GL30.glBindVertexArray;
import static org.lwjgl.opengl.GL30.glGenVertexArrays;

import Cardinal.Settings.Context;

class Batch {
	private final byte POSITION_SIZE = 2;
	private final byte UV_SIZE = 2;
	private final byte TEX_ID_SIZE = 1;
	private final byte COLOR_SIZE = 4;
	private final byte TRANS_SIZE = 2;
	private final byte FACTOR_SIZE = 1;
	private final byte POSITION_OFFSET = 0;
	private final byte UV_OFFSET = POSITION_OFFSET + POSITION_SIZE * Float.BYTES;
	private final byte TEX_ID_OFFSET = UV_OFFSET + UV_SIZE * Float.BYTES;
	private final byte COLOR_OFFSET = TEX_ID_OFFSET + TEX_ID_SIZE * Float.BYTES;
	private final byte TRANS_OFFSET = COLOR_OFFSET + COLOR_SIZE * Float.BYTES;
	private final byte FACTOR_OFFSET = TRANS_OFFSET + TRANS_SIZE * Float.BYTES;
	private final byte VERTEX_SIZE = POSITION_SIZE + UV_SIZE + TEX_ID_SIZE + COLOR_SIZE + TRANS_SIZE + FACTOR_SIZE;
	private final byte VERTEX_SIZE_BYTES = VERTEX_SIZE * Float.BYTES;

	private final short BATCH_SIZE = Context.BATCH_SIZE;

	private int VertexArrayObject, VertexBufferObject;
	private boolean IsFull;
	private float[] VertexList;

	private int[] SlotList = {
			0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
			26, 27, 28, 29, 30, 31, 32
	};

	private List<Sprite> SpriteList;
	private List<String> TextureList;

	Batch () {
		SpriteList = new List<Sprite> (Sprite.class);

		VertexList = new float[BATCH_SIZE * 4 * VERTEX_SIZE];
		IsFull = false;

		TextureList = new List<String> (String.class);

	}

	void Design () {
		VertexArrayObject = glGenVertexArrays ();
		glBindVertexArray (VertexArrayObject);

		VertexBufferObject = glGenBuffers ();
		glBindBuffer (GL_ARRAY_BUFFER, VertexBufferObject);
		glBufferData (GL_ARRAY_BUFFER, VertexList.length * Float.BYTES, GL_DYNAMIC_DRAW);

		int ElementBufferObject = glGenBuffers ();
		int[] IndexList = CreateIndexList ();

		glBindBuffer (GL_ELEMENT_ARRAY_BUFFER, ElementBufferObject);
		glBufferData (GL_ELEMENT_ARRAY_BUFFER, IndexList, GL_STATIC_DRAW);

		glVertexAttribPointer (0, POSITION_SIZE, GL_FLOAT, false, VERTEX_SIZE_BYTES, POSITION_OFFSET);
		glVertexAttribPointer (1, UV_SIZE, GL_FLOAT, false, VERTEX_SIZE_BYTES, UV_OFFSET);
		glVertexAttribPointer (2, TEX_ID_SIZE, GL_FLOAT, false, VERTEX_SIZE_BYTES, TEX_ID_OFFSET);
		glVertexAttribPointer (3, COLOR_SIZE, GL_FLOAT, false, VERTEX_SIZE_BYTES, COLOR_OFFSET);
		glVertexAttribPointer (4, TRANS_SIZE, GL_FLOAT, false, VERTEX_SIZE_BYTES, TRANS_OFFSET);
		glVertexAttribPointer (5, FACTOR_SIZE, GL_FLOAT, false, VERTEX_SIZE_BYTES, FACTOR_OFFSET);

	}

	private int[] CreateIndexList () {
		int[] ElementList = new int[6 * BATCH_SIZE];

		for (short Index = 0; Index < BATCH_SIZE; Index++) {
			short OffsetIndex = (short) (6 * Index);
			short Offset = (short) (4 * Index);

			ElementList[OffsetIndex + 0] = Offset + 3;
			ElementList[OffsetIndex + 1] = Offset + 2;
			ElementList[OffsetIndex + 2] = Offset + 0;
			ElementList[OffsetIndex + 3] = Offset + 0;
			ElementList[OffsetIndex + 4] = Offset + 2;
			ElementList[OffsetIndex + 5] = Offset + 1;

		}

		return ElementList;

	}

	boolean SetSprite (Sprite Item) {
		if (!Batch.Disposable (Item)) {
			if (!IsFull) {
				SpriteList.Push (Item);
				LoadVertexProperties ((short) (SpriteList.Size () - 1));

				if (!TextureList.Contains (Item.GetTexture ())) {
					TextureList.Push (Item.GetTexture ());

				}

				if (SpriteList.Size () >= BATCH_SIZE) {
					IsFull = true;

				}

			} else {
				return true;

			}

		}

		return false;

	}

	private void LoadVertexProperties (short Place) {
		Sprite Item = SpriteList.ItemAt (Place);
		int Offset = Place * 4 * VERTEX_SIZE;

		byte TextureID = 0;

		final float COLOR_R = Item.GetR ();
		final float COLOR_G = Item.GetB ();
		final float COLOR_B = Item.GetG ();
		final float COLOR_A = Item.GetA ();

		for (byte Index = 0; Index < TextureList.Size (); Index++) {
			if (TextureList.ItemAt (Index) == Item.GetTexture ()) {
				TextureID = (byte) (Index + 1);
				break;

			}

		}

		float X = 1.0f, Y = 1.0f, Angle = Item.GetAngle ();
		Angle = (float) Math.toRadians (Angle);

		for (byte Index = 0; Index < 4; Index++) {
			switch (Index) {
				case 1:
					Y = 0.0f;
					break;

				case 2:
					X = 0.0f;
					break;

				case 3:
					Y = 1.0f;
					break;

				default:
					break;

			}

			float TemporaryX = (-0.5f + X) * Item.GetWidth ();
			float TemporaryY = (-0.5f + Y) * Item.GetHeight ();

			float RotatedX = (float) (Math.cos (Angle) * TemporaryX + Math.sin (Angle) * TemporaryY);
			float RotatedY = (float) (Math.cos (Angle) * TemporaryY - Math.sin (Angle) * TemporaryX);

			float PositionX = RotatedX + Item.GetTrueX ();
			float PositionY = RotatedY + Item.GetTrueY ();

			VertexList[Offset] = PositionX;
			VertexList[Offset + 1] = PositionY;
			VertexList[Offset + 2] = Item.GetCoordinateList ()[Index].x;
			VertexList[Offset + 3] = Item.GetCoordinateList ()[Index].y;
			VertexList[Offset + 4] = TextureID;
			VertexList[Offset + 5] = COLOR_R;
			VertexList[Offset + 6] = COLOR_G;
			VertexList[Offset + 7] = COLOR_B;
			VertexList[Offset + 8] = COLOR_A;
			VertexList[Offset + 9] = Item.GetTransitionList ()[Index].x;
			VertexList[Offset + 10] = Item.GetTransitionList ()[Index].y;
			VertexList[Offset + 11] = Item.GetFactor ();

			Offset += VERTEX_SIZE;

		}

	}

	void Terminate () {
		SpriteList.Clear ();

	}

	static boolean Disposable (Sprite Item) {
		final short WIDTH = Item.GetWidth ();
		final short HEIGHT = Item.GetHeight ();
		final float SPRITE_X = Item.GetX () + (WIDTH * 0.5f);
		final float SPRITE_Y = Item.GetY () + (HEIGHT * 0.5f);
		final short SCREEN_WIDTH = Stage.GetWidth ();
		final short SCREEN_HEIGHT = Stage.GetHeight ();
		final float SCREEN_X = Camera.GetX () + (SCREEN_WIDTH * 0.5f);
		final float SCREEN_Y = Camera.GetY () + (SCREEN_HEIGHT * 0.5f);

		final double DISPOSABLE = Context.BATCH_ERASE_FACTOR;
		final boolean CHECK_ONE = SPRITE_X > (SCREEN_X - SCREEN_WIDTH) * DISPOSABLE;
		final boolean CHECK_TWO = SPRITE_X > (SCREEN_X + SCREEN_WIDTH) * DISPOSABLE;
		final boolean CHECK_THREE = SPRITE_Y > (SCREEN_Y - SCREEN_HEIGHT) * DISPOSABLE;
		final boolean CHECK_FOUR = SPRITE_Y > (SCREEN_Y + SCREEN_HEIGHT) * DISPOSABLE;

		if (CHECK_ONE || CHECK_TWO || CHECK_THREE || CHECK_FOUR) {
			return false;

		}

		return true;

	}

	void Update () {
		for (short Index = 0; Index < SpriteList.Size (); Index++) {
			LoadVertexProperties (Index);
			SpriteList.ItemAt (Index).Update ();

		}

		glBindBuffer (GL_ARRAY_BUFFER, VertexBufferObject);
		glBufferSubData (GL_ARRAY_BUFFER, 0, VertexList);

		Shader.Apply ();
		Shader.UploadMatrixFour ("uProjection", Camera.ProjectionMatrix ());
		Shader.UploadMatrixFour ("uView", Camera.ViewMatrix ());
		Shader.UploadIntegerArray ("uTextures", SlotList);

		for (short Index = 0; Index < TextureList.Size (); Index++) {
			glActiveTexture (GL_TEXTURE0 + Index + 1);
			Basin.GetTexture (TextureList.ItemAt (Index)).Bind ();

		}

		glBindVertexArray (VertexArrayObject);

		glEnableVertexAttribArray (0);
		glEnableVertexAttribArray (1);
		glEnableVertexAttribArray (2);
		glEnableVertexAttribArray (3);
		glEnableVertexAttribArray (4);
		glEnableVertexAttribArray (5);

		glDrawElements (GL_TRIANGLES, SpriteList.Size () * 6, GL_UNSIGNED_INT, 0);

		glDisableVertexAttribArray (0);
		glDisableVertexAttribArray (1);
		glEnableVertexAttribArray (2);
		glEnableVertexAttribArray (3);
		glEnableVertexAttribArray (4);
		glEnableVertexAttribArray (5);

		glBindVertexArray (0);

		for (short Index = 0; Index < TextureList.Size (); Index++) {
			glActiveTexture (GL_TEXTURE0 + Index);
			glBindTexture (GL_TEXTURE_2D, 0);

		}

		Shader.Detach ();

	}

}