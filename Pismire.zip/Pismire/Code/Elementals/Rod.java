package Elementals;

import static org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT;

public class Rod {
	private Sprite Basic, Event;
	private boolean IsActivated, IsPressed;
	private float Coordinate, CurrentValue, DesiredX, DesiredWidth;
	private Range RangeX, RangeY;

	public Rod (float X, float Y, Atlas Source, short Value, short Width, short Height) {
		this.Basic = Source.GetSprite (Value);
		this.Basic.SetIsStatic (true);
		this.Coordinate = Basic.GetCoordinateList ()[0].x;
		this.Basic.GetCoordinateList ()[0].x = 0.0f;
		this.Basic.GetCoordinateList ()[1].x = 0.0f;
		this.Basic.SetLayer ((byte) 8);
		this.Basic.SetX ((X - Width * 0.5f));
		this.Basic.SetY (Y);
		this.Event = Source.GetSprite ((short) (Value + 1));
		this.Event.SetIsStatic (true);
		this.Event.SetLayer ((byte) 7);
		this.Event.SetWidth ((short) 50);
		this.Event.SetHeight (Height);
		this.Event.SetX (Basic.GetX ());
		this.Event.SetY (Basic.GetY ());
		this.DesiredWidth = Width;
		this.DesiredX = X;
		this.Basic.SetWidth ((short) 0);
		this.Basic.SetHeight (Height);
		this.CurrentValue = 0;
		this.RangeX = new Range (Event.GetX () - Event.GetWidth () * 0.5f,
				Event.GetX () + Event.GetWidth () * 0.5f);
		this.RangeY = new Range (Event.GetY () - Event.GetHeight () * 0.5f,
				Event.GetY () + Event.GetHeight () * 0.5f);
		this.IsActivated = false;
		this.IsPressed = false;

	}

	void Update (float X, float Y) {
		if (MouseTracker.ButtonPressed ((short) GLFW_MOUSE_BUTTON_LEFT, true)) {
			if (!IsPressed) {
				IsPressed = true;

				if (X >= RangeX.X && X <= RangeX.Y && Y >= RangeY.X && Y <= RangeY.Y) {
					IsActivated = true;

				}

			}

			if (IsActivated) {
				SetValue ((X - (DesiredX - DesiredWidth * 0.5f)) / DesiredWidth);

			}

		} else {
			IsActivated = false;
			IsPressed = false;

		}

	}

	private void SetValue (float Value) {
		if (Value < 0.0f) {
			Value = 0.0f;

		}

		if (Value > 1.0f) {
			Value = 1.0f;

		}

		CurrentValue = Value;
		Basic.GetCoordinateList ()[0].x = Value * Coordinate;
		Basic.GetCoordinateList ()[1].x = Value * Coordinate;
		Basic.SetWidth ((short) (DesiredWidth * Value));
		Basic.SetX ((DesiredX + Basic.GetWidth () * 0.5f) - DesiredWidth * 0.5f);
		Event.SetX ((Value * DesiredWidth * 0.5f) + Basic.GetX ());
		RangeX = new Range (Event.GetX () - Event.GetWidth () * 0.5f, Event.GetX () + Event.GetWidth () * 0.5f);
		RangeY = new Range (Event.GetY () - Event.GetHeight () * 0.5f,
				Event.GetY () + Event.GetHeight () * 0.5f);

	}

	public float GetValue () {
		return CurrentValue;

	}

	void SetOpen (boolean IsOpen) {
		if (IsOpen) {
			Basic.SetLayer ((byte) 7);
			Event.SetLayer ((byte) 7);

		} else {
			Basic.SetLayer ((byte) 0);
			Event.SetLayer ((byte) 0);

		}

	}

}