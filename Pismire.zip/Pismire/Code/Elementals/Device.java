package Elementals;

class Device {
	private static List<Board> BoardList;

	static void Design () {
		BoardList = new List<Board> (Board.class);

	}

	static void Update () {
		for (short Index = 0; Index < BoardList.Size (); Index++) {
			if (BoardList.ItemAt (Index).IsOpen ()) {
				BoardList.ItemAt (Index).Update (MouseTracker.GetX (true), MouseTracker.GetY (true));

			}

		}

	}

	static void SetBoard (Board Item) {
		if (!BoardList.Contains (Item)) {
			Device.BoardList.Push (Item);

		} else {
			Device.BoardList.Pull (Item);

		}

	}

}