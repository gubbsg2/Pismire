package Elementals;

public abstract class Task {
	public abstract void Run ();

}