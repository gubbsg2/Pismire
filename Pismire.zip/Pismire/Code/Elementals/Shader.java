package Elementals;

import static org.lwjgl.opengl.GL11.GL_FALSE;
import static org.lwjgl.opengl.GL20.GL_COMPILE_STATUS;
import static org.lwjgl.opengl.GL20.GL_FRAGMENT_SHADER;
import static org.lwjgl.opengl.GL20.GL_LINK_STATUS;
import static org.lwjgl.opengl.GL20.GL_VERTEX_SHADER;
import static org.lwjgl.opengl.GL20.glAttachShader;
import static org.lwjgl.opengl.GL20.glCompileShader;
import static org.lwjgl.opengl.GL20.glCreateProgram;
import static org.lwjgl.opengl.GL20.glCreateShader;
import static org.lwjgl.opengl.GL20.glGetProgrami;
import static org.lwjgl.opengl.GL20.glGetShaderi;
import static org.lwjgl.opengl.GL20.glGetUniformLocation;
import static org.lwjgl.opengl.GL20.glLinkProgram;
import static org.lwjgl.opengl.GL20.glShaderSource;
import static org.lwjgl.opengl.GL20.glUniform1iv;
import static org.lwjgl.opengl.GL20.glUniformMatrix4fv;
import static org.lwjgl.opengl.GL20.glUseProgram;

import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

class Shader {
	private static int ShaderProgramID;
	private static String VertexShader, FragmentShader;

	static void LoadSources (String File) {
		String Source = "";
		boolean IsThrowable = false;

		try {
			Source = new String (Files.readAllBytes (Paths.get ("Assets/Shaders/" + File)));

		} catch (IOException Hoarder) {
			FileRetrieveException Exception = new FileRetrieveException ("Shader Could Not Be Found");
			Application.Terminate (Exception);

		}

		String[] SplitString = Source.split ("(#type)( )+([a-zA-Z]+)");

		short Index = (short) (Source.indexOf ("#type") + 6);
		short EndOfLine = (short) Source.indexOf ("\r\n", Index);
		String FirstPattern = Source.substring (Index, EndOfLine).trim ();

		Index = (short) (Source.indexOf ("#type", EndOfLine) + 6);
		EndOfLine = (short) Source.indexOf ("\r\n", Index);
		String SecondPattern = Source.substring (Index, EndOfLine).trim ();

		switch (FirstPattern) {
			case "vertex":
				VertexShader = SplitString[1];
				break;

			case "fragment":
				FragmentShader = SplitString[2];
				break;

			default:
				IsThrowable = true;
				break;

		}

		switch (SecondPattern) {
			case "vertex":
				VertexShader = SplitString[1];
				break;

			case "fragment":
				FragmentShader = SplitString[2];
				break;

			default:
				IsThrowable = true;
				break;

		}

		if (IsThrowable) {
			BrokenCodeException Exception = new BrokenCodeException ("Unexpected Keyword");
			Application.Terminate (Exception);

		}

	}

	static void Compile () {
		int VertexID, FragmentID;

		VertexID = glCreateShader (GL_VERTEX_SHADER);
		glShaderSource (VertexID, VertexShader);
		glCompileShader (VertexID);

		byte Success = (byte) glGetShaderi (VertexID, GL_COMPILE_STATUS);
		boolean IsThrowable = false;

		if (Success == GL_FALSE) {
			IsThrowable = true;

		}

		FragmentID = glCreateShader (GL_FRAGMENT_SHADER);
		glShaderSource (FragmentID, FragmentShader);
		glCompileShader (FragmentID);

		Success = (byte) glGetShaderi (FragmentID, GL_COMPILE_STATUS);

		if (Success == GL_FALSE) {
			IsThrowable = true;

		}

		if (IsThrowable) {
			OperatorReturnException Exception = new OperatorReturnException (
					"Shader Could Not Be Compiled");
			Application.Terminate (Exception);

		}

		ShaderProgramID = glCreateProgram ();
		glAttachShader (ShaderProgramID, VertexID);
		glAttachShader (ShaderProgramID, FragmentID);
		glLinkProgram (ShaderProgramID);

		Success = (byte) glGetProgrami (ShaderProgramID, GL_LINK_STATUS);

		if (Success == GL_FALSE) {
			OperatorReturnException Exception = new OperatorReturnException ("Shader Could Not Be Linked");
			Application.Terminate (Exception);

		}

	}

	static void Apply () {
		glUseProgram (ShaderProgramID);

	}

	static void Detach () {
		glUseProgram (0);

	}

	static void UploadMatrixFour (String VariableName, Matrix4f Matrix) {
		int VariableLocation = glGetUniformLocation (ShaderProgramID, VariableName);
		FloatBuffer MatrixBuffer = BufferUtils.createFloatBuffer (16);
		Matrix.get (MatrixBuffer);
		glUniformMatrix4fv (VariableLocation, false, MatrixBuffer);

	}

	static void UploadIntegerArray (String VariableName, int[] ValueList) {
		int VariableLocation = glGetUniformLocation (ShaderProgramID, VariableName);
		glUniform1iv (VariableLocation, ValueList);

	}

}