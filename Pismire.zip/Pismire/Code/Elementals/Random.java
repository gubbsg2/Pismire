package Elementals;

public class Random {
	public static double Double (double Minimum, double Maximum) {
		return Math.random () * (Maximum - Minimum + 1) + Minimum;

	}

	public static float Float (float Minimum, float Maximum) {
		return (float) Double (Minimum, Maximum);

	}

	public static int Integer (int Minimum, int Maximum) {
		return (int) Math.floor (Double (Minimum, Maximum));

	}

}