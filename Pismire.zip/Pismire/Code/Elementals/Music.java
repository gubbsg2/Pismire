package Elementals;

import static org.lwjgl.openal.AL10.AL_GAIN;
import static org.lwjgl.openal.AL10.AL_LOOPING;
import static org.lwjgl.openal.AL10.AL_TRUE;
import static org.lwjgl.openal.AL10.alSourcef;
import static org.lwjgl.openal.AL10.alSourcei;

import Cardinal.Settings.Context;

public class Music {
	private String Audio;
	private float Volume;
	private static float MaxVolume = Context.SOUND_VOLUME;
	private boolean IsStarting = false, IsPlaying = false;

	public Music (String Path) {
		Audio = Path;
		Basin.SetRoot (Path);
		alSourcei (Basin.GetRoot (Audio).GetSource (), AL_LOOPING, AL_TRUE);
		alSourcef (Basin.GetRoot (Audio).GetSource (), AL_GAIN, Volume);
		Chest.SetMusic (this);

	}

	public void Play () {
		IsStarting = true;

		if (Volume < 0.0f) {
			Basin.GetRoot (Audio).Play ();
			IsPlaying = true;

		}

	}

	public void Terminate () {
		IsStarting = false;
		Volume -= 0.00017f;

	}

	void Update (long Elapsed) {
		if (Volume < MaxVolume) {
			if (IsStarting) {
				Volume += 0.00017f * Elapsed;

			} else {
				if (Volume < 0.0f) {
					if (IsPlaying) {
						Basin.GetRoot (Audio).Stop ();
						IsPlaying = false;

					}

				} else {
					Volume -= 0.00017f * Elapsed;

				}

			}

		} else if (Volume > MaxVolume) {
			Volume = MaxVolume;

		}

		if (Volume > 0) {
			alSourcef (Basin.GetRoot (Audio).GetSource (), AL_GAIN, Volume);

		}

	}

	String GetAudio () {
		return this.Audio;

	}

}