package Elementals;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.glfw.GLFW.glfwSwapBuffers;
import static org.lwjgl.opengl.GL.createCapabilities;
import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glEnable;

import org.lwjgl.stb.STBImage;

import Cardinal.Settings.Context;

class Renderer {
	private static boolean IsStarted = false;

	private static List<Sprite> SpriteListOne, SpriteListTwo, SpriteListThree, SpriteListFour, SpriteListFive,
			SpriteListSix, SpriteListSeven, SpriteListEight;
	private static List<Batch> BatchList;

	static void Initialize () {
		glfwMakeContextCurrent (Stage.Handle ());

		if (Context.ENABLE_VYSNC) {
			glfwSwapInterval (1);

		}

		STBImage.stbi_set_flip_vertically_on_load (true);
		Camera.Design (0, 0, Stage.GetWidth (), Stage.GetHeight ());

		BatchList = new List<Batch> (Batch.class);
		SpriteListOne = new List<Sprite> (Sprite.class);
		SpriteListTwo = new List<Sprite> (Sprite.class);
		SpriteListThree = new List<Sprite> (Sprite.class);
		SpriteListFour = new List<Sprite> (Sprite.class);
		SpriteListFive = new List<Sprite> (Sprite.class);
		SpriteListSix = new List<Sprite> (Sprite.class);
		SpriteListSeven = new List<Sprite> (Sprite.class);
		SpriteListEight = new List<Sprite> (Sprite.class);

		createCapabilities ();
		glEnable (GL_BLEND);
		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glClearColor (0.0f, 0.0f, 0.0f, 1.0f);

		SetShader (Context.SHADER_FILE);

	}

	static void DrawSprite (Sprite Item, long Elapsed) {
		if (!Batch.Disposable (Item)) {
			boolean IsSet = false;

			for (short Index = 0; Index < BatchList.Size (); Index++) {
				if (!BatchList.ItemAt (Index).SetSprite (Item)) {
					IsSet = true;
					break;

				} else {
					IsSet = false;

				}

			}

			if (!IsSet) {
				Batch LatestBatch = new Batch ();
				LatestBatch.Design ();
				BatchList.Push (LatestBatch);
				LatestBatch.SetSprite (Item);

			}

		}

	}

	static void Update (long Elapsed) {
		Camera.Update ();
		glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		for (short Index = 0; Index < SpriteListOne.Size (); Index++) {
			DrawSprite (SpriteListOne.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListTwo.Size (); Index++) {
			DrawSprite (SpriteListTwo.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListThree.Size (); Index++) {
			DrawSprite (SpriteListThree.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListFour.Size (); Index++) {
			DrawSprite (SpriteListFour.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListFive.Size (); Index++) {
			DrawSprite (SpriteListFive.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListSix.Size (); Index++) {
			DrawSprite (SpriteListSix.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListSeven.Size (); Index++) {
			DrawSprite (SpriteListSeven.ItemAt (Index), Elapsed);

		}

		for (short Index = 0; Index < SpriteListEight.Size (); Index++) {
			DrawSprite (SpriteListEight.ItemAt (Index), Elapsed);

		}

		for (byte Index = 0; Index < BatchList.Size (); Index++) {
			BatchList.ItemAt (Index).Update ();
			BatchList.ItemAt (Index).Terminate ();

		}

		glfwSwapBuffers (Stage.Handle ());

	}

	private static void SetShader (String File) {
		Shader.LoadSources (File);
		Shader.Compile ();

	}

	static void Terminate () {
		Basin.Terminate ();

	}

	static void SetStarted (boolean IsStarted) {
		Renderer.IsStarted = IsStarted;

	}

	static void SetSprite (Sprite Item) {
		switch (Item.GetLayer ()) {
			case 0:
				Renderer.SpriteListOne.Pull (Item);
				Renderer.SpriteListTwo.Pull (Item);
				Renderer.SpriteListThree.Pull (Item);
				Renderer.SpriteListFour.Pull (Item);
				Renderer.SpriteListFive.Pull (Item);
				Renderer.SpriteListSix.Pull (Item);
				Renderer.SpriteListSeven.Pull (Item);
				Renderer.SpriteListEight.Pull (Item);

			case 1:
				Renderer.SpriteListOne.Push (Item);
				break;

			case 2:
				Renderer.SpriteListTwo.Push (Item);
				break;

			case 3:
				Renderer.SpriteListThree.Push (Item);
				break;

			case 4:
				Renderer.SpriteListFour.Push (Item);
				break;

			case 5:
				Renderer.SpriteListFive.Push (Item);
				break;

			case 6:
				Renderer.SpriteListSix.Push (Item);
				break;

			case 7:
				Renderer.SpriteListSeven.Push (Item);
				break;

			case 8:
				Renderer.SpriteListEight.Push (Item);
				break;

		}

	}

	static boolean GetStarted () {
		return Renderer.IsStarted;

	}

}