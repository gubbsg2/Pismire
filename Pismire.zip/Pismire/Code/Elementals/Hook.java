package Elementals;

import static org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT;

public class Hook {
	private Range RangeX, RangeY;
	private boolean IsActivated, IsPressed, IsReleased;
	private Sprite Basic, Event;
	private Task OnTrigger;

	public Hook (float X, float Y, Atlas Source, short Value, Task OnTrigger, short Width, short Height) {
		this.Basic = Source.GetSprite (Value);
		this.Basic.SetIsStatic (true);
		this.Basic.SetLayer ((byte) 7);
		this.Basic.SetX (X);
		this.Basic.SetY (Y);
		this.Event = Source.GetSprite ((short) (Value + 1));
		this.Event.SetIsStatic (true);
		this.Event.SetX (Basic.GetX ());
		this.Event.SetY (Basic.GetY ());
		this.Basic.SetWidth (Width);
		this.Event.SetWidth (Width);
		this.Basic.SetHeight (Height);
		this.Event.SetHeight (Height);
		this.RangeX = new Range (Basic.GetX () - Basic.GetWidth () * 0.5f,
				Basic.GetX () + Basic.GetWidth () * 0.5f);
		this.RangeY = new Range (Basic.GetY () - Basic.GetHeight () * 0.5f,
				Basic.GetY () + Basic.GetHeight () * 0.5f);
		this.IsActivated = false;
		this.OnTrigger = OnTrigger;

	}

	void Update (float X, float Y) {
		if (MouseTracker.ButtonPressed ((short) GLFW_MOUSE_BUTTON_LEFT, true)) {
			IsReleased = false;

			if (!IsPressed) {
				IsPressed = true;

				if (X >= RangeX.X && X <= RangeX.Y && Y >= RangeY.X && Y <= RangeY.Y) {
					Basic.SetLayer ((byte) 0);
					Event.SetLayer ((byte) 7);
					IsActivated = true;

				}

			}

		} else {
			IsPressed = false;

			if (!IsReleased) {
				IsReleased = true;

				if (IsActivated) {
					IsActivated = false;
					Basic.SetLayer ((byte) 7);
					Event.SetLayer ((byte) 0);

					if (X >= RangeX.X && X <= RangeX.Y && Y >= RangeY.X && Y <= RangeY.Y) {
						OnTrigger.Run ();

					}

				}

			}

		}

	}

	void SetOpen (boolean IsOpen) {
		if (IsOpen) {
			if (IsPressed) {
				Basic.SetLayer ((byte) 0);
				Event.SetLayer ((byte) 7);

			} else {
				Basic.SetLayer ((byte) 7);
				Event.SetLayer ((byte) 0);

			}

		} else {
			Basic.SetLayer ((byte) 0);
			Event.SetLayer ((byte) 0);

		}

	}

}