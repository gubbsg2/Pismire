package Elementals;

import org.joml.Vector2f;

public class Atlas {
	private short TotalWidth, TotalHeight, ItemWidth, ItemHeight;

	private String Source;
	private Sprite[] SpriteList;

	public Atlas (String Source, short Amount, short Width, short Height) {
		Basin.SetTexture (Source);

		this.Source = Source;
		this.TotalWidth = Basin.GetTexture (Source).GetWidth ();
		this.TotalHeight = Basin.GetTexture (Source).GetHeight ();

		Design (Amount, Width, Height);

	}

	private void Design (short Amount, short Width, short Height) {
		SpriteList = new Sprite[Amount];

		ItemWidth = Width;
		ItemHeight = Height;

		short CurrentX = 0, CurrentY = (short) (TotalHeight - Height);

		for (byte Index = 0; Index < Amount; Index++) {
			float Right = (CurrentX + Width) / (float) TotalWidth;
			float Top = (CurrentY + Height) / (float) TotalHeight;
			float Left = CurrentX / (float) TotalWidth;
			float Bottom = CurrentY / (float) TotalHeight;

			Vector2f[] TextureCoordinateList = {
					new Vector2f (Right, Top), new Vector2f (Right, Bottom),
					new Vector2f (Left, Bottom), new Vector2f (Left, Top)
			};

			Sprite Item = new Sprite (Source, 0, 0);
			Item.SetCoordinateList (TextureCoordinateList);
			SpriteList[Index] = Item;

			CurrentX += Width;

			if (CurrentX >= TotalWidth) {
				CurrentX = 0;
				CurrentY -= Height;

			}

		}

	}

	public Sprite GetSprite (short Slot) {
		if (SpriteList != null) {
			Sprite This = SpriteList[Slot];
			Sprite Item = new Sprite (Source, 0, 0);
			Vector2f[] CoordinateList = new Vector2f[4];

			for (byte Index = 0; Index < CoordinateList.length; Index++) {
				CoordinateList[Index] = new Vector2f (This.GetCoordinateList ()[Index].x,
						This.GetCoordinateList ()[Index].y);

			}

			Item.SetWidth (ItemWidth);
			Item.SetHeight (ItemHeight);
			Item.SetCoordinateList (CoordinateList);
			return Item;

		} else {
			UnpreparedGadgetException Exception = new UnpreparedGadgetException (
					"Atlas Has Not Been Parsed");
			Application.Terminate (Exception);

		}

		return null;

	}

	public Sprite GetSprite (short Slot, Sprite Item) {
		if (SpriteList != null) {
			Sprite This = SpriteList[Slot];
			Vector2f[] CoordinateList = new Vector2f[4];

			for (byte Index = 0; Index < CoordinateList.length; Index++) {
				CoordinateList[Index] = new Vector2f (This.GetCoordinateList ()[Index].x,
						This.GetCoordinateList ()[Index].y);

			}

			Item.SetCoordinateList (CoordinateList);
			return Item;

		} else {
			UnpreparedGadgetException Exception = new UnpreparedGadgetException (
					"Atlas Has Not Been Parsed");
			Application.Terminate (Exception);

		}

		return null;

	}

}